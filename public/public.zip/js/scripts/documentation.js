$((function(){"use strict";$("body").scrollspy({target:"#sidebar-page-navigation"})}));
