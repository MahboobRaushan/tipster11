/*=========================================================================================
  File Name: custom_script.js
  Description: My own JS
  ----------------------------------------------------------------------------------------

==========================================================================================*/

// toast showing message

  function toastr_message_show(type,message)
  {
     
     toastr.options = {
                      "closeButton": true,
                      "newestOnTop": false,
                      "progressBar": true,
                      "positionClass": "toast-top-right",
                      "preventDuplicates": false,
                      "onclick": null,
                      "showDuration": "300",
                      "hideDuration": "1000",
                      "timeOut": "5000",
                      "extendedTimeOut": "1000",
                      "showEasing": "swing",
                      "hideEasing": "linear",
                      "showMethod": "fadeIn",
                      "hideMethod": "fadeOut"
                    }
        if(type=='error')
        {
           toastr.error(message);
        }  
      else if(type=='success')
        {
           toastr.success(message);
        }
        else if(type=='info')
        {
           toastr.info(message);
        }
        else if(type=='warning')
        {
           toastr.warning(message);
        }
        

        
  }
