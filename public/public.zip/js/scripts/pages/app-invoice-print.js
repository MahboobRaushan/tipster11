$((function(){"use strict";window.print()}));
