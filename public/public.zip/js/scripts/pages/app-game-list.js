/*=========================================================================================
    File Name: app-game-list.js
    Description: Game List page
    --------------------------------------------------------------------------------------
    Item Name: Vuexy  - Vuejs, HTML & Laravel Admin Dashboard Template
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/game/pixinvent

==========================================================================================*/
$(function () {
  ('use strict');



  var dtGameTable = $('.game-list-table'),
    newGameSidebar = $('.new-game-modal'),
    editGameSidebar = $('.edit-game-modal'),
    newGameForm = $('.add-new-game'),
    editGameForm = $('.edit-new-game'),
    select = $('.select2'),
    dtContact = $('.dt-contact'),
    statusObj = {
      2: { title: 'Restrict', class: 'badge-light-warning' },
      1: { title: 'Active', class: 'badge-light-success' },
      0: { title: 'Inactive', class: 'badge-light-secondary' }
    };

  var assetPath = '../../../app-assets/',
    gameView = 'app-game-view-account.html';

  if ($('body').attr('data-framework') === 'laravel') {
    assetPath = $('body').attr('data-asset-path');
    gameView = assetPath + 'app/game/view/account';
  }

  select.each(function () {
    var $this = $(this);
    $this.wrap('<div class="position-relative"></div>');
    $this.select2({
      // the following code is used to disable x-scrollbar when click in select input and
      // take 100% width in responsive also
      dropdownAutoWidth: true,
      width: '100%',
      dropdownParent: $this.parent()
    });
  });
 


  function initializeDataTable(){

     table = dtGameTable.DataTable();
      table.destroy();

    // Games List datatable
    if (dtGameTable.length) {
      dtGameTable.DataTable({

       
        //ajax: assetPath + 'data/game-list.json', // JSON file to add data
        ajax: assetPath + 'games/ajaxlist', // JSON file to add data      
        
        columns: [
          // columns according to JSON
          { data: '' },
          { data: 'id' },
          { data: 'icon_path' },
          { data: 'name' },
        
         
          { data: 'status' },
          { data: '' }
        ],
        columnDefs: [
          {
            // For Responsive
            className: 'control',
            orderable: false,
            responsivePriority: 2,
            targets: 0,
            render: function (data, type, full, meta) {
              return '';
            }
          },
           {
            // Game  name and email
            targets: 1,
            responsivePriority: 4,
            render: function (data, type, full, meta) {
              var id = full['id'];
              
              
              return id;
            }
          },
          {
            // Image
            targets: 2,
            responsivePriority: 4,
            render: function (data, type, full, meta) {
              var $name = full['name'],
               
               
                $image = full['icon_path'];
              if ($image) {
                // For Avatar image
                var $output =
                  '<img src="' + assetPath +  $image + '" alt="Avatar" height="32" width="32">';
              } else {
                // For Avatar badge
                 var stateNum = Math.floor(Math.random() * 6) + 1;
                var states = ['success', 'danger', 'warning', 'info', 'dark', 'primary', 'secondary'];
                var $state = states[stateNum];
                  var  $name = full['name'],
                 
                
                $initials = $name.match(/\b\w/g) || [];
                $initials = (($initials.shift() || '') + ($initials.pop() || '')).toUpperCase();
                $output = '<span class="avatar-content">' + $initials + '</span>';
              }
               var colorClass = $image === '' ? ' bg-light-' + $state + ' ' : '';
              // Creates full output for row
              var $row_output =
                '<div class="d-flex justify-content-left align-items-center">' +
                '<div class="avatar-wrapper">' +
                '<div class="avatar ' +
                colorClass +
                ' me-1">' +
                $output +
                '</div>' +
                '</div>' +
               
                '</div>';
              return $row_output;
            }
          },
          {
            // Game  name 
            targets: 3,
            responsivePriority: 4,
            render: function (data, type, full, meta) {
              var $name = full['name'];
               
              
              var $row_output =
                '<div class="d-flex justify-content-left align-items-center">' +
              
                '<div class="d-flex flex-column">' +
                '<span class="fw-bolder">' +
                $name +
                '</span>' +
                
                '</div>' +
                '</div>';
              return $row_output;
            }
          },
                   
         
          {
            // Game Status
            targets: 4,
            render: function (data, type, full, meta) {
              var $status = full['status'];

              return (
                '<span class="badge rounded-pill ' +
                statusObj[$status].class +
                '" text-capitalized>' +
                statusObj[$status].title +
                '</span>'
              );
            }
          },
          {
            // Actions
            targets: -1,
            title: 'Actions',
            orderable: false,
            render: function (data, type, full, meta) {
               var id = full['id'];
                var ultihtml =  '<div class="btn-group">' +
                '<a class="btn btn-sm dropdown-toggle hide-arrow" data-bs-toggle="dropdown">...</a>' +
                '<div class="dropdown-menu dropdown-menu-end">';

                if(custom_get_all_permissions_access_Array.indexOf("game.view") > -1 ){
                  ultihtml=ultihtml+'<a class="dropdown-item view_modal" data-id="'+id+'"  >' +
                feather.icons['file-text'].toSvg({ class: 'font-small-4 me-50' }) +
                'Details</a>';
                }

               

                 if(custom_get_all_permissions_access_Array.indexOf("game.edit") > -1 ){
                   ultihtml=ultihtml+'<a   class="dropdown-item edit-record edit_modal" data-id="'+id+'"  >' +
                feather.icons['edit'].toSvg({ class: 'font-small-4 me-50' }) +
                'Edit</a>';
                } 

                 if(custom_get_all_permissions_access_Array.indexOf("game.delete") > -1 ){
                   ultihtml=ultihtml+'<a   class="dropdown-item delete-record delete_modal" data-id="'+id+'"  >' +
                feather.icons['trash-2'].toSvg({ class: 'font-small-4 me-50' }) +
                'Delete</a>';
                } 

                 ultihtml=ultihtml+'</div>' +
                
                '</div>'; 

              return (
                /*'<div class="btn-group">' +
                '<a class="btn btn-sm dropdown-toggle hide-arrow" data-bs-toggle="dropdown">...</a>' +
                '<div class="dropdown-menu dropdown-menu-end">' +
                '<a class="dropdown-item view_modal" data-id="'+id+'"  >' +
                feather.icons['file-text'].toSvg({ class: 'font-small-4 me-50' }) +
                'Details</a>' +               
                '<a   class="dropdown-item edit-record edit_modal" data-id="'+id+'"  >' +
                feather.icons['edit'].toSvg({ class: 'font-small-4 me-50' }) +
                'Edit</a><a   class="dropdown-item delete-record delete_modal" data-id="'+id+'"  >' +
                feather.icons['trash-2'].toSvg({ class: 'font-small-4 me-50' }) +
                'Delete</a>' +
                '</div>' +
                '</div>'*/
                ultihtml
              );
            }
          }
        ],
        order: [[1, 'desc']],
        dom:
          '<"d-flex justify-content-between align-items-center header-actions mx-2 row mt-75"' +
          '<"col-sm-12 col-lg-4 d-flex justify-content-center justify-content-lg-start" l>' +
          '<"col-sm-12 col-lg-8 ps-xl-75 ps-0"<"dt-action-buttons d-flex align-items-center justify-content-center justify-content-lg-end flex-lg-nowrap flex-wrap"<"me-1"f>B>>' +
          '>t' +
          '<"d-flex justify-content-between mx-2 row mb-1"' +
          '<"col-sm-12 col-md-6"i>' +
          '<"col-sm-12 col-md-6"p>' +
          '>',
        language: {
          sLengthMenu: 'Show _MENU_',
          search: 'Search',
          searchPlaceholder: 'Search..'
        },
        // Buttons with Dropdown
        buttons: [
          {
            extend: 'collection',
            className: 'btn btn-outline-secondary dropdown-toggle me-2',
            text: feather.icons['external-link'].toSvg({ class: 'font-small-4 me-50' }) + 'Export',
            buttons: [
              {
                extend: 'print',
                text: feather.icons['printer'].toSvg({ class: 'font-small-4 me-50' }) + 'Print',
                className: 'dropdown-item',
                exportOptions: { columns: [1, 3,4] }
              },
              {
                extend: 'csv',
                text: feather.icons['file-text'].toSvg({ class: 'font-small-4 me-50' }) + 'Csv',
                className: 'dropdown-item',
                exportOptions: { columns: [1, 3,4] }
              },
              {
                extend: 'excel',
                text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel',
                className: 'dropdown-item',
                exportOptions: { columns: [1, 3,4] }
              },
              {
                extend: 'pdf',
                text: feather.icons['clipboard'].toSvg({ class: 'font-small-4 me-50' }) + 'Pdf',
                className: 'dropdown-item',
                exportOptions: { columns: [1, 3,4] }
              },
              {
                extend: 'copy',
                text: feather.icons['copy'].toSvg({ class: 'font-small-4 me-50' }) + 'Copy',
                className: 'dropdown-item',
                exportOptions: { columns: [1, 3,4] }
              }
            ],
            init: function (api, node, config) {
              $(node).removeClass('btn-secondary');
              $(node).parent().removeClass('btn-group');
              setTimeout(function () {
                $(node).closest('.dt-buttons').removeClass('btn-group').addClass('d-inline-flex mt-50');
              }, 50);
            }
          },
          {
            text: custom_get_all_permissions_access_Array.indexOf("game.create") > -1 ? 'Add New Game':'',
            className: custom_get_all_permissions_access_Array.indexOf("game.create") > -1 ? 'add-new btn btn-primary':'',
            attr: custom_get_all_permissions_access_Array.indexOf("game.create") > -1 ? {
              'data-bs-toggle': 'modal',
              'data-bs-target': '#modals-slide-in'
            }:'',
            init: custom_get_all_permissions_access_Array.indexOf("game.create") > -1 ? function (api, node, config) {
              $(node).removeClass('btn-secondary');
            }:''
          }
        ],
        // For responsive popup
        responsive: {
          details: {
            display: $.fn.dataTable.Responsive.display.modal({
              header: function (row) {
                var data = row.data();
                return 'Details of ' + data['name'];
              }
            }),
            type: 'column',
            renderer: function (api, rowIdx, columns) {
              var data = $.map(columns, function (col, i) {
                return col.columnIndex !== 5 // ? Do not show row in modal popup if title is blank (for check box)
                  ? '<tr data-dt-row="' +
                      col.rowIdx +
                      '" data-dt-column="' +
                      col.columnIndex +
                      '">' +
                      '<td>' +
                      col.title +
                      ':' +
                      '</td> ' +
                      '<td>' +
                      col.data +
                      '</td>' +
                      '</tr>'
                  : '';
              }).join('');
              return data ? $('<table class="table"/>').append('<tbody>' + data + '</tbody>') : false;
            }
          }
        },
        language: {
          paginate: {
            // remove previous & next text from pagination
            previous: '&nbsp;',
            next: '&nbsp;'
          }
        }
      });
    }



  }

  initializeDataTable();

 

  // Create Form Validation
  if (newGameForm.length) {
    newGameForm.validate({
      errorClass: 'error',
      rules: {
        'name': {
          required: true
        },
        
      }
    });


     $('#basic-icon-default-icon').change(function(){
          let reader = new FileReader();
          reader.onload = (e) => { 
          $('#preview-image-before-upload').attr('src', e.target.result); 
          }
          reader.readAsDataURL(this.files[0]); 
          });

    newGameForm.on('submit', function (e) {
      var isValid = newGameForm.valid();
      e.preventDefault();
      if (isValid) {

         
          var actionType = $('#btn-save').val();
          $('#btn-save').html('Sending..');


          var formData = new FormData(this);
          
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              //data: $('#postForm').serialize(),
              url: assetPath + 'games/add',
              method:"POST",
               data:new FormData(this),
               dataType:'JSON',
               contentType: false,
               cache: false,
               processData: false,
              success: function (data) {
                 
               
                    //alert(JSON.stringify(data));

                    if(data.status=='ok')
                    {
                      $('#postForm').trigger("reset");
                      $('#modals-slide-in').modal('hide');
                      $('#btn-save').html('Save Changes');
                      toastr_message_show('success',data.message);
                      initializeDataTable();

                       $('#preview-image-before-upload').attr("src", 'images/icons/file-icons/onedrive.png');
                    }
                    else 
                    {                    
                      
                      
                      if(Array.isArray(data.message))
                      {
                        toastr_message_show('error',Object.values(data.message));
                      }
                      else 
                      {
                        toastr_message_show('error',data.message);
                      }
                    }
                            
                   
                  
              },
              error: function (data) {
                  alert(JSON.stringify(data));
                  $('#btn-save').html('Save Changes');
              }
          });
        

        newGameSidebar.modal('hide');
      }
    });
  }

// Edit Form Validation
  if (editGameForm.length) {
    editGameForm.validate({
      errorClass: 'error',
      rules: {
        'name': {
          required: true
        },       
       
        'status': {
          required: true
        }
      }
    });

  $('#basic-icon-default-icon_edit').change(function(){
          let reader = new FileReader();
          reader.onload = (e) => { 
          $('#preview-image-before-upload_edit').attr('src', e.target.result); 
          }
          reader.readAsDataURL(this.files[0]); 
          });

    editGameForm.on('submit', function (e) {
      var isValid = editGameForm.valid();
      e.preventDefault();
      if (isValid) {

         
          var actionType = $('#btn-save_edit').val();
          $('#btn-save_edit').html('Sending..');

          var formData = new FormData(this);

          //var form = document.getElementById('postForm_edit'); //id of form
        //var formData = new FormData(form);
       // var formData = new FormData(form[1]);

      // var formData = $('#postForm_edit').serialize();
     

         var edit_id = $('#edit_id').val();
          
          //alert(JSON.stringify(formData));
          
          $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
             
              url: assetPath + 'games/update/'+edit_id,
              method: "POST",
               data:formData,
               dataType:'JSON',
               contentType: false,
               cache: false,
               processData: false,
              success: function (data) {
                 
               
                  //alert(JSON.stringify(data));
                 //console.log( data);                 

                  
                    //alert(JSON.stringify(data));

                    if(data.status=='ok')
                    {
                      $('#postForm_edit').trigger("reset");
                      $('#modals-slide-in-edit').modal('hide');
                      $('#btn-save_edit').html('Save Changes');
                      toastr_message_show('success',data.message);
                      initializeDataTable();
                    }
                    else 
                    {                    
                      if(Array.isArray(data.message))
                      {
                        toastr_message_show('error',Object.values(data.message));
                      }
                      else 
                      {
                        toastr_message_show('error',data.message);
                      }
                    }
                            
                   
                  
              },
              error: function (data) {
                  //alert(JSON.stringify(data));
                  $('#btn-save_edit').html('Save Changes');
              }
          });
        

        editGameSidebar.modal('hide');
      }
    });
  }
   

    $(document).on('click', '.edit_modal', function () {
      var id = $(this).data("id");
      
      var url = assetPath + 'games/'+id;    

      
       $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              data: $('#postForm').serialize(),
              url: url,
              type: "POST",
              dataType: 'json',
              success: function (data) {    
                 //console.log( data); 
                 $('#edit_id').val(data.id);  
                 $('#basic-icon-default-fullname_edit').val(data.name);
               
                $('#basic-icon-default-order_no_edit').val(data.order_no);


                 $("#basic-icon-default-status_edit").val(data.status);
                  $('#basic-icon-default-status_edit').trigger('change'); 

                  if(data.icon_path !='')
                  {
                    $('#preview-image-before-upload_edit').attr("src", data.icon_path);
                  }

                 


                 $('#modals-slide-in-edit').modal('show') ;   
                  
              },
              error: function (data) {

                  console.log( data);  
                  
              }
          });

       
    });


      $(document).on('click', '.view_modal', function () {
      var id = $(this).data("id");
      
      var url = assetPath + 'games/'+id;    

      
       $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              data: [],
              url: url,
              type: "POST",
              dataType: 'json',
              success: function (data) {    
                 //console.log( data); 
                 
                 var st_status = '';
                 var d_stat = data.status;
                 d_stat = parseInt(d_stat);
                 if(d_stat==0)
                 {
                   st_status = '<span class="badge rounded-pill badge-light-secondary text-capitalized">Inactive</span>';
                 }
                 else if(d_stat==1)
                 {
                   st_status = '<span class="badge rounded-pill badge-light-success text-capitalized">Active</span>';
                 }
               
                 var htmlcont = '';
                 htmlcont = htmlcont+'<div class="mb-1">  <label class="form-label" >Name : '+data.name+'</label>   </div>';
                 if(data.icon_path !='')
                 {
                  htmlcont = htmlcont+'<div class="mb-1">  <label class="form-label" >Image :<img src="'+data.icon_path+'" width="100" /></label></div>';
                 }

                  htmlcont = htmlcont+' <div class="mb-1">  <label class="form-label" >Order No : '+data.order_no+'</label>   </div>  <div class="mb-1">   <label class="form-label" >Status : '+st_status+'</label>     </div>  ';
                 
                 $('#details_modal_body_content').html(htmlcont);

                 $('#modals-slide-in-view').modal('show') ; 

                 
                  
              },
              error: function (data) {
                  //alert(JSON.stringify(data));
                  console.log( data);  
                  
              }
          });

       
    });

     $(document).on('click', '.delete_modal', function () {
        var id = $(this).data("id");

        
        $('#delete_id').val(id);
        $('#myModal_delete').modal('show') ;

       });

      $(document).on('click', '#btn-save_delete', function () {
        var id = $('#delete_id').val();
         $.ajax({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              data: [],
              url: assetPath + 'games/'+id,
              type: "DELETE",
              dataType: 'json',
              success: function (data) {
                 
               
                  //alert(JSON.stringify(data));
                 //console.log( data);                 

                  
                    //alert(JSON.stringify(data));
                    if(data.status=='ok')
                    {                    
                      toastr_message_show('success',data.message);
                      initializeDataTable();
                    }
                    else 
                    { 
                      toastr_message_show('error',Object.values(data.message));
                    }
                            
                   
                  
              },
              error: function (data) {
                  alert(JSON.stringify(data));
                  $('#btn-save_edit').html('Save Changes');
              }
          });
        
        
        $('#myModal_delete').modal('hide') ;

       });

     

  
});
